# Compilar
```
iverilog -o processador.vvp calc1.v controle.v ula.v BancoReg.v memory.v
```
# Executar
```
vvp processador.vvp
```
